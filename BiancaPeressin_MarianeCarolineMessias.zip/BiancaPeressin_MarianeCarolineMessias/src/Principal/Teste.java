package Principal;

public class Teste
{
    //Chamada mo método polimórifico:
    public void ExecutarAgradecimento(Pessoa P)
    {
        P.Agradecer();
    }
}
