package Principal;

public class InstituicaoDeEnsino
{
    //Atributos da classe InstituicaoDeEnsino:
    public String Instituicao;
    
    //Construtores da classe InstituicaoDeEnsino:
    public InstituicaoDeEnsino(String Instituicao)
    {
        this.Instituicao = Instituicao;
    }

    //Métodos GET da classe InstituicaoDeEnsino:
    public String getInstituicao() {
        return Instituicao;
    }
    
    //Métodos SET da classe InstituicaoDeEnsino:
    public void setInstituicao(String Instituicao)
    {
        this.Instituicao = Instituicao;
    }
    
    
}
